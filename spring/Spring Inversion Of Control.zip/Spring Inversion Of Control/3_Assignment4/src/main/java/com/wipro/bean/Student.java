package com.wipro.bean;

public class Student {
	
	private String studentId;
	private String studentName;
	private Test studentTest;
	
	public String getStudentId() {
		return studentId;
	}
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public Test getStudentTest() {
		return studentTest;
	}
	public void setStudentTest(Test studentTest) {
		this.studentTest = studentTest;
	}
	public void show() {
		System.out.print("Student [studentId : " + studentId);
		System.out.print(", studentName : " + studentName);
		System.out.print(", studentTest : " + studentTest + "]");
	}
}
