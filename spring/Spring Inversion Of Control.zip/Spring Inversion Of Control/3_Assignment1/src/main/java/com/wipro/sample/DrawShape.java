package com.wipro.sample;

public class DrawShape {
	
	private String msg;
	private Shape s;

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public Shape getS() {
		return s;
	}

	public void setS(Shape s) {
		this.s = s;
	}
	public void show() {
		System.out.println("Draw Shape Class");
		System.out.println(msg);
	}
}