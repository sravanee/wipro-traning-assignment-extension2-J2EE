package com.wipro.sample;

public class ConstructorMessage {
	
	private String message = null;
	public ConstructorMessage(String msg) {
		// TODO Auto-generated constructor stub
		
		this.message = msg;
	}

	void show() {
		System.out.println("Hello "+message);
	}
}
